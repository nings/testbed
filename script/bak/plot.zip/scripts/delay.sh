#!/bin/bash

scriptPath=$(echo $0 | sed 's/\/delay.sh//');
echo "delay analysis (delay.eps, delayNetwork.eps)"

sqlite3 -batch -separator ' ' trace.sqlite "SELECT substr(e.dataobjectId,1,40) as dObjId, e.time, e.eventName, d.nodeId, substr(e.nodeId,6) FROM events as e LEFT JOIN devices as d ON d.name=e.device WHERE (e.eventName='EVENT_TYPE_DATAOBJECT_SEND_SUCCESSFUL' OR e.eventName='EVENT_TYPE_DATAOBJECT_NEW') AND (substr(e.nodeId,1,4)='peer' OR substr(e.nodeId,1,1)='-') ORDER BY dObjId, d.nodeId, e.nodeId;" | sed 's/  / ??? /' > tmp-delay-all

# filter out multiple receives and build src-dst pairs
awk -f $scriptPath/delayFilter.awk tmp-delay-all > delay.txt

# network view
awk -f $scriptPath/delayNetwork.awk delay.txt > tmp-delay-net
awk '/node / {if ($5 > 0) print $4;}' < tmp-delay-net | sort -n | awk '{print $1, FNR}' | sed 's/,/./' > tmp-delay
awk '/node / {cnt[$5]++; if ($5>maxHop) maxHop=$5;} END {for (i=1;i<=maxHop;i++) {print i, cnt[i];};}' < tmp-delay-net > tmp-hop
awk '/r_delay/ {print $3;}' < tmp-delay-net | sort -n | awk '{print $1, FNR}' | sed 's/,/./' > tmp-r_delay
awk '/r_hop/ {print $3;}' < tmp-delay-net | sort -n | awk '{print $1, FNR}' | sed 's/,/./' > tmp-r_hop

# ... update match.sqlite
echo "attach 'trace.sqlite' as trace;" > tmp-delay-match
awk '{if ($2=="node") {print "UPDATE match SET numHop="$5" WHERE dataobjectId=*"$1"* AND nodeName=(SELECT name from trace.devices where nodeId=*"$3"*);"}}' tmp-delay-net | sed "s/*/'/g" >> tmp-delay-match
sqlite3 -batch match.sqlite < tmp-delay-match


# - delay
cat $scriptPath/delayDelay-gnuplot.begin > delay.gplot
numLines=$(wc -l tmp-delay | awk '{print $1;}')
PLOT="\"tmp-delay\" using 1:(\$2/"$numLines") ls 1 notitle"
echo "plot "$PLOT >> delay.gplot



# - hop
cat $scriptPath/delayHop-gnuplot.begin > delay.gplot
numLines=$(awk '/node / {if ($5 > 0) cnt++;} END {print cnt;}' < tmp-delay-net)
PLOT="\"tmp-hop\" using 1:(\$2/("$numLines")) with boxes notitle"
echo "plot "$PLOT >> delay.gplot
gnuplot delay.gplot


# node delay cdf
awk '{print $2}' delay.txt | sort -n | awk '{print $1, FNR}' > tmp-delay

cat $scriptPath/delay-gnuplot.begin > delay.gplot
numLines=$(wc -l tmp-delay | awk '{print $1;}')
PLOT="\"tmp-delay\" using 1:(\$2/"$numLines"*100) with linespoints ls 1 notitle"
echo "plot "$PLOT >> delay.gplot
gnuplot delay.gplot

# topology plot
awk -f $scriptPath/delay2gv.awk tmp-delay-all > topology.gv


#rm delay.txt
#rm delay.gplot
#rm tmp-delay*
#rm tmp-hop
#rm tmp-r_delay
#rm tmp-r_hop
