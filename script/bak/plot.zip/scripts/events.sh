#!/bin/bash

scriptPath=$(echo $0 | sed 's/\/events.sh//');
echo "event visualization (events.eps) ... may take a few minutes"


sqlite3 -batch -separator ' ' trace.sqlite "SELECT prevName, eName, count(*) FROM eventGraph GROUP BY prevName, eName ORDER BY prevName" | sed 's/EVENT_TYPE_//g' > events.txt

echo .. generate graphviz file
awk -f $scriptPath/txt2gv.awk events.txt > events.gv
open /Applications/Graphviz.app events.gv
