#!/bin/bash

rm trace.sqlite
cat ../../HaggleTestScripts/sql.begin > trace.sql

for x in $(ls -d node-*)
do 
   	echo $x

	echo .. create sql
   	awk -f ../../HaggleTestScripts/trace2sql.awk -v device=$x $x/trace.log >> trace.sql

done

cat ../../HaggleTestScripts/sql.end >> trace.sql

echo .. evaluate
sqlite3 -batch -separator ' ' trace.sqlite < trace.sql | sed 's/EVENT_TYPE_//g' > events.txt

