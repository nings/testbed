CREATE TABLE table_map_dataobjects_to_attributes_via_rowid (ROWID INTEGER PRIMARY KEY, dataobject_rowid TEXT, attr_rowid TEXT, timestamp DATE, UNIQUE (dataobject_rowid,attr_rowid) ON CONFLICT IGNORE);

CREATE TABLE table_map_nodes_to_attributes_via_rowid (ROWID INTEGER PRIMARY KEY, node_rowid TEXT, attr_rowid TEXT, weight INTEGER, timestamp DATE, UNIQUE (node_rowid,attr_rowid) ON CONFLICT IGNORE);


CREATE VIEW view_map_dataobjects_to_attributes_via_rowid_dynamic AS SELECT * FROM table_map_dataobjects_to_attributes_via_rowid as da;

CREATE VIEW view_match_dataobjects_and_nodes AS SELECT da.dataobject_rowid as dataobject_rowid, na.node_rowid as node_rowid, count(*) as mcount, sum(na.weight) as weight, min(na.weight)=-1 as dataobject_not_match, da.timestamp as dataobject_timestamp FROM view_map_dataobjects_to_attributes_via_rowid_dynamic as da INNER JOIN table_map_nodes_to_attributes_via_rowid as na ON na.attr_rowid=da.attr_rowid GROUP by da.dataobject_rowid, na.node_rowid;

CREATE TABLE receivedDataobjects (dataobjectId TEXT, device TEXT, UNIQUE (dataobjectId, device) ON CONFLICT IGNORE);

CREATE VIEW receivedDataobjects_ext AS SELECT r.*, d.nodeId FROM receivedDataobjects as r LEFT JOIN devices as d ON d.name=r.device;

CREATE VIEW matchOverview AS select d.dataobjectId, n.nodeID, m.mcount, m.weight, (select count(*) from receivedDataobjects_ext as r where r.nodeId=n.nodeId and r.dataobjectId=d.dataobjectId) as inDatastore from dataobjects as d left join devices as n left join view_match_dataobjects_and_nodes as m on m.dataobject_rowid=d.dataobjectId and m.node_rowid=n.nodeId where d.type='Data';