# --- table_map_dataobjects_to_attributes_via_rowid

query="update table_map_dataobjects_to_attributes_via_rowid set dataobject_rowid=(SELECT d.rowid from table_dataobjects as d where hex(d.id)=dataobject_rowid);"
sqlite3 -batch -separator ' ' $1 "$query"


# below an alternative approach, unfortunately not faster

query="CREATE VIEW view_map_dataobjects_to_attributes_via_rowid AS SELECT m.rowid, d.rowid as dataobject_rowid, m.attr_rowid FROM table_map_dataobjects_to_attributes_via_rowid as m LEFT JOIN table_dataobjects as d ON hex(d.id)=m.dataobject_rowid;"
#sqlite3 -batch -separator ' ' $1 "$query"

query="CREATE TABLE copy_map_dataobjects_to_attributes_via_rowid (rowid, dataobject_rowid, attr_rowid);"
#sqlite3 -batch -separator ' ' $1 "$query"

query="INSERT INTO copy_map_dataobjects_to_attributes_via_rowid SELECT * FROM view_map_dataobjects_to_attributes_via_rowid;"
#sqlite3 -batch -separator ' ' $1 "$query"

query="DROP VIEW view_map_dataobjects_to_attributes_via_rowid;"
#sqlite3 -batch -separator ' ' $1 "$query"

query="DELETE FROM table_map_dataobjects_to_attributes_via_rowid;"
#sqlite3 -batch -separator ' ' $1 "$query"

query="INSERT INTO table_map_dataobjects_to_attributes_via_rowid SELECT * FROM copy_map_dataobjects_to_attributes_via_rowid;"
#sqlite3 -batch -separator ' ' $1 "$query"

query="DROP TABLE copy_map_dataobjects_to_attributes_via_rowid;"
#sqlite3 -batch -separator ' ' $1 "$query"



# --- table_map_nodes_to_attributes_via_rowid

query="update table_map_nodes_to_attributes_via_rowid set node_rowid=(SELECT n.rowid from table_nodes as n where hex(n.id)=node_rowid);"
sqlite3 -batch -separator ' ' $1 "$query"
