#!/bin/bash

scriptPath=$(dirname $0);
logPath=$(pwd)



for experiment in $(ls -1d */)
do
	echo "---" $experiment "---"

	cd $logPath/$experiment
	if [ -d 1 ]
	then echo "";
	else
		gunzip 1.tar.gz;
		tar -xf 1.tar;
	fi
	cd 1

	# --- create database	
	sh $scriptPath/createDatabase.sh;
	
	echo ".. calculating overhead"

	# SUCCESS TO NODES
	query="select count(*) from overheadHelp WHERE eventName='EVENT_TYPE_DATAOBJECT_SEND_SUCCESSFUL' AND nodeId2!='-' AND nodeId2!='[Unk' AND nodeId2!='3ced';"
	successToNodes=$(sqlite3 -batch -separator ' ' trace.sqlite "$query")
	
	# SUCCESS > NEW
	query="select count(*) from overheadHelp as send LEFT JOIN overheadHelp as receive ON send.dobjId=receive.dobjId AND send.nodeId2=receive.nodeId1 WHERE send.eventName='EVENT_TYPE_DATAOBJECT_SEND_SUCCESSFUL' AND receive.eventName='EVENT_TYPE_DATAOBJECT_NEW';"
	successNew=$(sqlite3 -batch -separator ' ' trace.sqlite "$query")
	
	# NEW > SUCCESS TO LUCKYME
	query="select count(*) from overheadHelp as a LEFT JOIN overheadHelp as b ON a.dobjId=b.dobjId AND a.nodeId1=b.nodeId1 WHERE a.eventName='EVENT_TYPE_DATAOBJECT_NEW' AND b.eventName='EVENT_TYPE_DATAOBJECT_SEND_SUCCESSFUL' AND b.nodeId2='3ced';"
	newToLuckyMe=$(sqlite3 -batch -separator ' ' trace.sqlite "$query")
	
	# --- print
	echo "EXPERIMENT | SUCCESS TO NODES | SUCCESS > NEW (ratio) | NEW > SUCCESS TO LUCKYME (ratio)"
	echo $expriment "|" $successToNodes "|" $successNew "("$[100 * $successNew / $successToNodes] "%) |" $newToLuckyMe "("$[100 * $newToLuckyMe / $successNew] "%)"

	cd

done