#!/bin/bash

scriptPath=$(dirname $0);

# --- create database
sh $scriptPath/createDatabase.sh

# --- timesync
# sh $scriptPath/timeSync.sh

# --- battery
#sh $scriptPath/battery.sh

# --- interpacket time (cdf)
sh $scriptPath/interpacket.sh

# --- delay
sh $scriptPath/delay.sh

# --- dataobject tree


# --- interface up/down
sh $scriptPath/iface.sh

# --- sequence
sh $scriptPath/sequence.sh

# --- contact time
sh $scriptPath/contact.sh

# --- inter-contact time
sh $scriptPath/intercontact.sh



