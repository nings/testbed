#!/bin/bash

# this script runs from outside the experiment folders. 

scriptPath=$(dirname $0);

plotcmd="plot "
i=0;
j=0;

title[1]='B'
title[2]='C'
title[3]='B fw'
title[4]='C fw'
title[5]='medium fw'
title[6]='weak fw'

cat $scriptPath/rankPlot-gnuplot.begin > rank.gplot


for e in mobicom-three-weakOverlap mobicom-three-weakOverlap-forwarding;
do 
	logpath=$e/1

	for n in node-9 node-14;
	do
		if [ -f rank-$e-$n ] 
		then 
			rm rank-$e-$n 
		fi

		echo $n

		i=$[i+1]
		query="SELECT rank FROM match WHERE isNodeDescription=0 AND isOwnData=0 AND isReceived AND nodeName='$n' ORDER BY rank;"
		sqlite3 -batch -separator ' ' $logpath/match.sqlite "$query" > tmp-rank-$e-$n
			
		awk -v y=$i -f $scriptPath/rankPlot.awk < tmp-rank-$e-$n | sed 's/,/\./g' > rank-$e-$n
		
		plotcmd=$plotcmd"\"rank-$e-$n\" using 1:2 with points ls $i notitle ,"
	done
	j=$[(j+1)%3]
done

plotcmd=$plotcmd"'nix' notitle"
echo $plotcmd >> rank.gplot
gnuplot rank.gplot


rm tmp-rank*
#rm map*