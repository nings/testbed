#!/bin/bash

scriptPath=$(dirname $0);
echo "contact time analysis (contactContact.eps)"

cat $scriptPath/contact-gnuplot.begin > contact.gplot
echo "" > tmp-contact-all

sqlite3 -batch -separator ' ' trace.sqlite "SELECT time, device, interfaceId, eventName FROM events WHERE eventName='EVENT_TYPE_NEIGHBOR_INTERFACE_UP' OR eventName='EVENT_TYPE_NEIGHBOR_INTERFACE_DOWN' ORDER BY device, interfaceId, time" > tmp-contact-sql

cat tmp-contact-sql | awk -f $scriptPath/contact.awk > tmp-contact-all
cat tmp-contact-all | sort -n | awk '{print $1, FNR}' > tmp-contact-all-cdf

numLines=$(wc -l tmp-contact-all-cdf | awk '{print $1;}')
PLOT="\"tmp-contact-all-cdf\" using 1:(1-\$2/"$numLines") with linespoints ls $i+1 notitle,"

PLOT=`echo $PLOT | sed -e 's/,$//'`
echo "plot "$PLOT >> contact.gplot

gnuplot contact.gplot

rm contact.gplot
rm tmp-contact*