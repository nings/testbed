query="update table_map_dataobjects_to_attributes_via_rowid set attr_rowid=(SELECT (name||'='||value) from table_attributes as a where a.rowid=attr_rowid);"
sqlite3 -batch $1 "$query"

query="update table_map_dataobjects_to_attributes_via_rowid set dataobject_rowid=(SELECT hex(id) from table_dataobjects as d where d.rowid=dataobject_rowid);"
sqlite3 -batch $1 "$query"

query="update table_map_nodes_to_attributes_via_rowid set attr_rowid=(SELECT (name||'='||value) from table_attributes as a where a.rowid=attr_rowid);"
sqlite3 -batch $1 "$query"

query="update table_map_nodes_to_attributes_via_rowid set node_rowid=(SELECT hex(id) from table_nodes as n where n.rowid=node_rowid);"
sqlite3 -batch $1 "$query"
