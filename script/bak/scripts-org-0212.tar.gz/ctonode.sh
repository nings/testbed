ssh user@node-$1
