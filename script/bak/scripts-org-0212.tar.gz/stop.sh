shutdown_nodes.sh 50
rm *.log
