#!/bin/bash

scriptPath=$(dirname $0);

query="SELECT dataobjectId, nodeName FROM match WHERE isNodeDescription=0 AND isOwnData=0 ORDER BY nodeName, ratio desc, isReceived desc;"
sqlite3 -batch -separator ' ' match.sqlite "$query" > tmp-matchRank

awk -f $scriptPath/matchRank.awk < tmp-matchRank > tmp-matchRank.sql

sqlite3 -batch match.sqlite < tmp-matchRank.sql

rm tmp-matchRank
rm tmp-matchRank.sql