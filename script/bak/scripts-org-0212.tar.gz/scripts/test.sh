#!/bin/bash


rm trace.sqlite

for x in $(ls -d node-*)
do 
   	echo $x

	echo .. create sql
	cat ../HaggleTestScripts/sql.begin > $x/trace.sql
   	awk -f ../HaggleTestScripts/trace2sql.awk $x $x/trace.log >> $x/trace.sql
	cat ../HaggleTestScripts/sql.end >> $x/trace.sql

   	echo .. evaluate
   	sqlite3 -batch -separator ' ' trace.sqlite < $x/trace.sql | sed 's/EVENT_TYPE_//g' > $x/events.txt

   	echo .. generate graphviz file
   	awk -f ../HaggleTestScripts/txt2gv.awk $x/events.txt > $x/events.gv
   	open /Applications/Graphviz.app $x/events.gv
done
