#!/bin/bash

scriptPath=$(dirname $0);

attach="attach 'trace.sqlite' as trace;"

query="SELECT round(min(time)+15) FROM events WHERE eventName='EVENT_TYPE_NEIGHBOR_INTERFACE_UP' OR eventName='EVENT_TYPE_DATAOBJECT_NEW';"
startTime=$(sqlite3 -batch -separator ' ' trace.sqlite "$query")

query="SELECT dev.name, d.createtime, d.xmlhdr FROM table_dataobjects as d LEFT JOIN trace.devices as dev ON dev.nodeId=lower(d.signee);"
sqlite3 -batch -separator '--separator--' all-nodes.db "$attach $query" > tmp-dobjs


awk -v startTime=$startTime -f $scriptPath/luckyMeObjects.awk tmp-dobjs | sed 's/,/./' | sort -n > tmp
awk '{if (substr($1,1,1)=="#") {if ($2!=prevDevice) {print $0;}; prevDevice=$2;} else {print $0}}' < tmp > luckyMe-trace
