#!/bin/bash

# this script runs from outside the experiment folders. 

scriptPath=$(dirname $0);

topN=10;
plotcmd="plot "
i=0;
j=0;

title[1]='average'
title[2]='max'
title[3]='min'
title[4]='node-5'
title[5]='medium forward'
title[6]='weak forward'

cat $scriptPath/meanAveragePrecision-gnuplot.begin > map.gplot


for e in experiment_19feb;
do 
	if [ -f map-$e ] 
	then 
		rm map-$e 
	fi

	logpath=$e

	for n in LG-1 LG-2 LG-4 LG-5 LG-6 LG-7 LG-8 LG-9 LG-10 LG-11 LG-12 LG-13 LG-15 LG-16 LG-17 LG-19 LG-20 LG-21 LG-23 LG-24;
	do
	echo $n
		i=$[i+1]
		query="SELECT ratio FROM match WHERE isNodeDescription=0 AND isOwnData=0 AND isReceived=1 and nodeName='$n' ORDER BY receiveTime;"
		sqlite3 -batch -separator ' ' $logpath/match.sqlite "$query" > tmp-meanAveragePrecision
	
	
#		if [ -f map-$e ] 
#		then 
#			rm map-$e 
#		fi
		
		for rel in 40 35 30 25 20 15 10;
		do
			awk -v relevant=$rel -f $scriptPath/meanAveragePrecision.awk < tmp-meanAveragePrecision | sed 's/,/\./g' >> map-$e
		done
		
		plotcmd=$plotcmd"\"map-$e\" using 1:2 with linespoints ls $i title '${title[$i]}' ,"
	done
	j=$[(j+1)%3]
done

plotcmd=$plotcmd"'nix' notitle"
echo $plotcmd >> map.gplot
gnuplot map.gplot


rm tmp-meanAveragePrecision
#rm map*