#!/bin/bash

scriptPath=$(dirname $0);
echo "battery analyis (battery.eps)"

cat $scriptPath/battery-gnuplot.begin > battery.gplot

i=0
for logPath in $(ls -d node-*)
do 
	if [ -f $logPath/title ]
	then device=$(cat $logPath/title);
	else device=$logPath;
	fi

	i=$[i+1]
	sqlite3 -batch -separator ' ' trace.sqlite "SELECT time, batteryStatus FROM resources WHERE batteryStatus NOT NULL AND device='$device'" | awk '{if (startTime==0) {startTime=$1}; print ($1-startTime)/3600, $2;}' | sed 's/,/./' > tmp-battery-$logPath
	PLOT=$PLOT"\"tmp-battery-$logPath\" using 1:2 with linespoints ls $i t \"$device\","
done
PLOT=`echo $PLOT | sed -e 's/,$//'`
echo "plot "$PLOT >> battery.gplot

gnuplot battery.gplot

rm battery.gplot
rm tmp-battery*