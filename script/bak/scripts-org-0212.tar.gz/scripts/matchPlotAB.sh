#!/bin/bash

scriptPath=$(dirname $0);

# -- data
nodeB="node-7"
nodeC="node-10"

# -- histogram A,B

queryB="select ratio, count(*), sum(isReceived) from match where nodeName='$nodeB' and isNodeDescription=0 and isOwnData=0 group by ratio order by ratio;"
sqlite3 -batch -separator ' ' match.sqlite "$queryB" > match-nodeB
queryC="select ratio, count(*), sum(isReceived) from match where nodeName='$nodeC' and isNodeDescription=0 and isOwnData=0 group by ratio order by ratio;"
sqlite3 -batch -separator ' ' match.sqlite "$queryC" > match-nodeC

# -- plot

cat $scriptPath/matchPlot-gnuplot.begin > match.gplot
PLOT="'match-nodeB' using 3 fs solid 1.00 title '{/Helvetica=18 received}', '' using (\$2-\$3):xticlabels(1) fs solid 0.1 title '{/Helvetica=18 not received}'"
echo "plot "$PLOT >> match.gplot
gnuplot match.gplot
mv match.eps match-nodeB.eps

cat $scriptPath/matchPlot-gnuplot.begin > match.gplot
PLOT="'match-nodeC' using 3 fs solid 1.00 title '{/Helvetica=18 received}', '' using (\$2-\$3):xticlabels(1) fs solid 0.1 title '{/Helvetica=18 not received}'"
echo "plot "$PLOT >> match.gplot
gnuplot match.gplot
mv match.eps match-nodeC.eps


# -- scatter

queryData="select dataobjectId, max(abs(nodeName='$nodeB')*ratio) as ratioB, max(abs(nodeName='$nodeC')*ratio) as ratioC, max(abs(nodeName='$nodeB')*isReceived) as isReceivedB, max(abs(nodeName='$nodeC')*isReceived) as isReceivedC from match where isNodeDescription=0 and isOwnData=0 group by dataobjectId order by ratioB desc, ratioC desc;"
queryNodeDescription="select dataobjectId, max(abs(nodeName='$nodeB')*ratio) as ratioB, max(abs(nodeName='$nodeC')*ratio) as ratioC, max(abs(nodeName='$nodeB')*isReceived) as isReceivedB, max(abs(nodeName='$nodeC')*isReceived) as isReceivedC from match where isNodeDescription=1 and isOwnData=0 group by dataobjectId order by ratioB desc, ratioC desc;"
sqlite3 -batch -separator ' ' match.sqlite "$queryData" > matchData
sqlite3 -batch -separator ' ' match.sqlite "$queryNodeDescription" > matchNodeDescription

cat $scriptPath/matchPlotScatter-gnuplot.begin > match.gplot
PLOT="'matchData' using 3:2:((\$4+\$5)/2+0.4) pt 31 ps variable notitle, 'matchNodeDescription' using 3:2:((\$4+\$5)/2+0.4) pt 5 ps variable notitle"
echo "plot "$PLOT >> match.gplot
gnuplot match.gplot




rm match.gplot
rm match-nodeB
rm match-nodeC
rm matchData
rm matchNodeDescription
