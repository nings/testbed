#!/bin/bash

scriptPath=$(dirname $0);
echo "event spread analysis (will take some time...)"

#sqlite3 -batch -separator ' ' connectivityEvents.sqlite "select e1.*, min(abs(e3.logTime-e1.logTime)) as contactTime, min(abs(e1.logTime-e2.logTime)) as nextHaggleEvent from events as e1 left join events as e2 on e1.nodeA=e2.nodeA and e1.nodeB=e2.nodeB and e1.expNum=e2.expNum and e1.action=e2.action left join events as e3 on e1.nodeA=e3.nodeA and e1.nodeB=e3.nodeB and e1.expNum=e3.expNum where e1.source='testbed' and e2.source='haggle' and e3.source='testbed' and e1.action='up' and e3.action='down' group by e1.logTime order by e1.relTime, nextHaggleEvent;" > tmp-connectivityEvents.log
# limit to link 0-1:  and e1.nodeA='0' and e1.nodeB='1'

awk -f $scriptPath/connectivityEvents-distribution.awk < tmp-connectivityEvents.log > tmp-connectivityEvents-distribution

# scenarioTime
awk '{print $1;}' < tmp-connectivityEvents-distribution | sort -n | awk '{print $1, FNR}' | sed 's/,/./' > tmp-cdf-scenarioTime
cat $scriptPath/connectivityEventsScenarioTime-gnuplot.begin > connectivityEventsScenarioTime.gplot
numLines=$(wc -l tmp-cdf-scenarioTime | awk '{print $1;}')
PLOT="\"tmp-cdf-scenarioTime\" using 1:(\$2/"$numLines") ls 1 notitle"
echo "plot "$PLOT >> connectivityEventsScenarioTime.gplot
gnuplot connectivityEventsScenarioTime.gplot

# duration
awk '{print $2;}' < tmp-connectivityEvents-distribution | sort -n | awk '{print $1, FNR}' | sed 's/,/./' > tmp-cdf-duration
cat $scriptPath/connectivityEventsDuration-gnuplot.begin > connectivityEventsDelay.gplot
numLines=$(wc -l tmp-cdf-duration | awk '{print $1;}')
PLOT="\"tmp-cdf-duration\" using 1:(\$2/"$numLines") ls 1 notitle"
echo "plot "$PLOT >> connectivityEventsDelay.gplot
gnuplot connectivityEventsDelay.gplot

# HaggleTime
awk '{print $3;}' < tmp-connectivityEvents-distribution | sort -n | awk '{print $1, FNR}' | sed 's/,/./' > tmp-cdf-haggleTime
cat $scriptPath/connectivityEventsHaggleTime-gnuplot.begin > connectivityEventsHaggleTime.gplot
numLines=$(wc -l tmp-cdf-haggleTime | awk '{print $1;}')
PLOT="\"tmp-cdf-haggleTime\" using 1:(\$2/"$numLines") ls 1 notitle"
echo "plot "$PLOT >> connectivityEventsHaggleTime.gplot
gnuplot connectivityEventsHaggleTime.gplot

# HaggleDelay
awk '{print $4;}' < tmp-connectivityEvents-distribution | sed 's/^0,00/999999/' | sort -n | awk '{print $1, FNR}' | sed 's/,/./' > tmp-cdf-haggleDelay
cat $scriptPath/connectivityEventsHaggleDelay-gnuplot.begin > connectivityEventsHaggleDelay.gplot
numLines=$(wc -l tmp-cdf-haggleDelay | awk '{print $1;}')
PLOT="\"tmp-cdf-haggleDelay\" using (\$1/1000):(\$2/"$numLines") ls 1 notitle"
echo "plot "$PLOT >> connectivityEventsHaggleDelay.gplot
gnuplot connectivityEventsHaggleDelay.gplot


# contactTime
cat $scriptPath/connectivityEventsContactTime-gnuplot.begin > connectivityEventsContactTime.gplot

sqlite3 -batch -separator ' ' connectivityEvents.sqlite "select logTime, action from events where source='haggle' and (nodeA='0')  order by nodeA, nodeB, logTime;" | awk '/up/ {upTime=$1} /down/ {print $1-upTime-14782}' > tmp-contactTime.log
sqlite3 -batch -separator ' ' connectivityEvents.sqlite "select logTime, action from events where source='haggle' and (nodeA='2')  order by nodeA, nodeB, logTime;" | awk '/up/ {upTime=$1} /down/ {print $1-upTime-24765}' >> tmp-contactTime.log
sqlite3 -batch -separator ' ' connectivityEvents.sqlite "select logTime, action from events where source='haggle' and (nodeA='4')  order by nodeA, nodeB, logTime;" | awk '/up/ {upTime=$1} /down/ {print $1-upTime-24794}' >> tmp-contactTime.log

sort -n tmp-contactTime.log | awk '{print $1, FNR}' | sed 's/,/./' > tmp-cdf-contactTime

numLines=$(wc -l tmp-cdf-contactTime | awk '{print $1;}')

PLOT="\"tmp-cdf-contactTime\" using (\$1/1000):(\$2/"$numLines") ls 1 notitle"
echo "plot "$PLOT >> connectivityEventsContactTime.gplot
gnuplot connectivityEventsContactTime.gplot


# periodic analysis
sqlite3 -batch -separator ' ' connectivityEvents.sqlite "select (e.logTime-f.logTime), e.nodeA, e.expNum, e.action from events as e LEFT JOIN firstEvent as f ON e.nodeA=f.nodeA AND e.expNum=f.expNum where source='haggle';" | awk '/up/ {upTime=$1} /down/ {print upTime, $1-upTime, (upTime%1000000)/1000}' > tmp-periodic.log






# rm tmp-connectivityEvents*
# rm tmp-cdf-scenarioTime