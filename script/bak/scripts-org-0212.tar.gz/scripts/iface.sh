#!/bin/bash

scriptPath=$(dirname $0);
echo "interface analysis (iface.eps)"

cat $scriptPath/iface-gnuplot.begin > iface.gplot

i=0
for logPath in $(ls -1d */)
do
	logPath=$(echo $logPath | sed 's/\///')
	if [ -f $logPath/title ]
	then device=$(cat $logPath/title);
	else device=$logPath;
	fi

	i=$[i+1]
	sqlite3 -batch -separator ' ' trace.sqlite "SELECT time, substr(eventName,12) FROM events WHERE eventName like '%_INTERFACE_%' AND device='$device'" | awk '{if (startTime==0) {startTime=$1}; print ($1-startTime)/60, $2;}' | sed 's/,/./' | sed 's/LOCAL_INTERFACE_UP/3/' | sed 's/LOCAL_INTERFACE_DOWN/2/' | sed 's/NEIGHBOR_INTERFACE_UP/1/' | sed 's/NEIGHBOR_INTERFACE_DOWN/0/' > tmp-iface-$logPath
	PLOT=$PLOT"\"tmp-iface-$logPath\" using 1:2 with points ls $i t \"$device\","
done
PLOT=`echo $PLOT | sed -e 's/,$//'`
echo "plot "$PLOT >> iface.gplot

gnuplot iface.gplot

rm iface.gplot
rm tmp-iface*