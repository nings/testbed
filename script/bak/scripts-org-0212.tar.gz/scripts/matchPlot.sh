#!/bin/bash

scriptPath=$(dirname $0);

# -- data
query="SELECT ratio, count(*), sum(isReceived and numHop=1), sum(isReceived and numHop>1) FROM match WHERE isNodeDescription=0 AND isOwnData=0 GROUP BY ratio ORDER BY ratio desc;"
sqlite3 -batch -separator ' ' match.sqlite "$query" > tmp-match

# -- plot
PLOT="'tmp-match' using 3 fs solid 1.00 notitle 'rec 1-hop', '' using 4 fs solid 0.5 title 'rec n-hop', '' using (\$2-\$3-\$4):xticlabels(1) fs solid 0.1 title 'inNet'"

cat $scriptPath/matchPlot-gnuplot.begin > match.gplot
echo "plot "$PLOT >> match.gplot
gnuplot match.gplot

rm match.gplot
#rm tmp-match
