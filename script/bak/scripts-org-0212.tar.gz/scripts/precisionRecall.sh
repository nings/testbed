#!/bin/bash

# this script runs from outside the experiment folders. 

scriptPath=$(dirname $0);

topN=10;
plotcmd="plot "
i=0;
j=0;


cat $scriptPath/precisionRecall-gnuplot.begin > precisionRecall.gplot


for e in experiment_19feb;
do 
	logpath=$e

	for n in LG-1;
	do
	echo $n
		i=$[i+1]
		query="SELECT ratio FROM match WHERE isNodeDescription=0 AND isOwnData=0 AND isReceived=1 and nodeName='$n' ORDER BY receiveTime;"
		sqlite3 -batch -separator ' ' $logpath/match.sqlite "$query" > tmp-precisionRecall

		if [ -f precisionRecall-$e-$n ] 
		then 
			rm precisionRecall-$e-$n 
		fi
		
		for rel in 40 30 20;
		do
			query="SELECT count(*) FROM match WHERE isNodeDescription=0 AND isOwnData=0 and nodeName='$n' and ratio>=$rel;"
			num_relevant_total=$(sqlite3 -batch $logpath/match.sqlite "$query");
			echo $num_relevant_total;
		
			awk -v relevant_level=$rel -v num_relevant_total=$num_relevant_total -f $scriptPath/precisionRecall.awk < tmp-precisionRecall | sed 's/,/\./g' > precisionRecall-$e-$n-$rel
			plotcmd=$plotcmd"\"precisionRecall-$e-$n-$rel\" using 1:2 with lines ls $i title 'ratio $rel' ,"
		done	
	done
	j=$[(j+1)%3]
done

plotcmd=$plotcmd"'nix' notitle"
echo $plotcmd >> precisionRecall.gplot
gnuplot precisionRecall.gplot


rm tmp-precisionRecall
rm precisionRecall-*