#!/bin/bash

scriptPath=$(echo $0 | sed 's/\/eventsOverview.sh//');
echo "delay analysis (delay.eps, delayNetwork.eps)"

sqlite3 -batch -separator ' ' trace.sqlite "SELECT d.name, round(e.time/3600), e.eventName FROM events as e LEFT JOIN devices as d ON e.device=d.name WHERE eventName='EVENT_TYPE_NODE_CONTACT_NEW' OR eventName='EVENT_TYPE_DATAOBJECT_NEW' OR eventName='EVENT_TYPE_DATAOBJECT_SEND_SUCCESSFUL' OR eventName='EVENT_TYPE_DATAOBJECT_SEND_FAILURE' ORDER BY d.name, e.time;" | sed 's/  / ??? /' > tmp-events

awk -f $scriptPath/eventsOverviewMotionChart.awk tmp-events > eventsMotionChartData.js

#rm tmp-events



