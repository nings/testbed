#!/bin/bash

scriptPath=$(dirname $0);
echo "topology analysis (topology.eps)"

# all dataobjects
sqlite3 -batch -separator ' ' trace.sqlite "SELECT substr(e.dataobjectId,0,40) as dObjId, e.time, e.eventId, d.nodeId, e.nodeId, (a.dataobjectId) as hasFile FROM events as e LEFT JOIN dobjContent as a ON substr(e.dataobjectId,0,40)=a.dataobjectId LEFT JOIN devices as d ON d.name=e.device WHERE (e.eventId=16 OR e.eventId=10) ORDER BY dObjId, d.nodeId, e.nodeId;" | sed 's/  / * /' > tmp-delay-all

# only dataobjects with content (eg, no node descriptions)
#sqlite3 -batch -separator ' ' trace.sqlite "SELECT substr(e.dataobjectId,0,40) as dObjId, e.time, e.eventId, d.nodeId, e.nodeId, (a.dataobjectId) as hasFile FROM events as e LEFT JOIN dobjContent as a ON substr(e.dataobjectId,0,40)=a.dataobjectId LEFT JOIN devices as d ON d.name=e.device WHERE (e.eventId=16 OR e.eventId=10) AND hasFile NOT NULL ORDER BY dObjId, d.nodeId, e.nodeId;" | sed 's/  / * /' > tmp-delay-all

# filter out multiple receives and build src-dst pairs
awk -f $scriptPath/delay2gv.awk tmp-delay-all > topology.gv


# >>> use GraphViz to view topology.gv

rm tmp-delay-all
