#java scenariorunner2 
#javac
#jar cf file *.class
java -classpath scenariorunner3.jar scenariorunner3 $1
#java -classpath scenariorunner2.jar scenariorunner2 $1
#example-experiment/scenario.xml
#example-experiment/scenario.xml
#$1 
