 ./startsce.sh ex$1/scenario.xml
