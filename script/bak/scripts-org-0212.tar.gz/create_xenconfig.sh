#!/bin/sh
#  Author Fredrik Bjurefors <fredrik.bjurefors@it.uu.se>
#  This script creates the xen config file as well as a swap image
#  in the proper location

USAGE() {
    echo "USAGE:"
    echo "$0 <node name>"
    echo "format: name-1"
    echo "don't pad the number"
    exit 1
}

if [ $# -lt 1 ];then
    USAGE
fi

NODENAME=$1;
cd $(dirname $0)

plate="node-xencfg.template"
tmpaddr=$(echo $NODENAME | awk -F- '{print $2}')
addr=$(($tmpaddr + 10))
destdir="../testbed/node"
confdir="$destdir/cfg"
swapimg="swap.img"
swapdir="$destdir/swap"
cowdir="$destdir/cow"

echo "Create $NODENAME"

echo "    Creating Config File"
cat $confdir/$plate | sed "s/\$NODENAME/$NODENAME/g" | sed "s/\$IP/$addr/g" | sed "s/\$NODENO/$tmpaddr/g" > $confdir/$NODENAME

echo "    Copy file system"
if [ ! -e $cowdir/$NODENAME.img ];then
	cp $cowdir/node.img $cowdir/$NODENAME.img
# TODO add error check.
fi

echo "FINISHED created $NODENAME";
exit 0

