#!/bin/bash

cd $(dirname $0)
./do_telnet $@
